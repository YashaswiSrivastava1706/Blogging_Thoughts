// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';

import BlogList from './components/BlogList';
import BlogDetail from './components/BlogDetail';
import BlogForm from './components/BlogForm';
import Navigation from './components/Navigation'; // Import the navigation component

function App() {
  return (
    <div className="App">
      <Router>
        <h1>My Blog Application</h1>
        <Navigation /> {/* Include the navigation component */}
        <Switch>
          <Route exact path="/" component={BlogList} />
          <Route path="/post/:id" component={BlogDetail} />
          <Route path="/add" component={BlogForm} />
        </Switch>
      </Router>
    </div>
  );
}

export default App;

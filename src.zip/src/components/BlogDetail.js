// src/components/BlogDetail.js
import React from 'react';

const BlogDetail = ({ post }) => {
  return (
    <div>
      <h2>Blog Detail</h2>
      <h3>{post.title}</h3>
      <p>{post.content}</p>
      {/* Add like, edit, and delete buttons here */}
    </div>
  );
};

export default BlogDetail;

// src/components/BlogForm.js
import React, { useState } from 'react';
import { useDispatch } from 'react-redux';
import { addPost } from '../redux/actions'; // Import your Redux actions

const BlogForm = () => {
  const [title, setTitle] = useState('');
  const [content, setContent] = useState('');
  const dispatch = useDispatch();

  const handleSubmit = () => {
    const newPost = {
      title,
      content,
      id: Date.now(), // You can generate a unique ID here
    };
    dispatch(addPost(newPost)); // Dispatch the addPost action
    setTitle('');
    setContent('');
  };

  return (
    <div>
      <h2>Add New Blog Post</h2>
      <input
        type="text"
        placeholder="Title"
        value={title}
        onChange={(e) => setTitle(e.target.value)}
      />
      <textarea
        placeholder="Content"
        value={content}
        onChange={(e) => setContent(e.target.value)}
      ></textarea>
      <button onClick={handleSubmit}>Add Post</button>
    </div>
  );
};

export default BlogForm;
